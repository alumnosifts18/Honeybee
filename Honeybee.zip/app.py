#!/usr/bin/env python
import csv
from datetime import datetime
from flask import Flask, render_template, redirect, url_for, flash, session
from flask_bootstrap import Bootstrap
from pathlib import Path
# from flask_moment import Moment
from flask_script import Manager
from forms import LoginForm, RegistrarForm, BuscarProductosxClienteForm, BuscarClientesxProductoForm

app = Flask(__name__)
manager = Manager(app)
bootstrap = Bootstrap(app)
# moment = Moment(app)

app.config['SECRET_KEY'] = 'ExamenParcial'

##########################
# FUNCIONES DE USO COMÚN #
##########################

#Función para validar el archivo CSV
def validarCSV():
	#Verificamos si existe el archivo en el directorio
	resultado=[0,1,2]
	my_file = Path("ventas.csv")
	if my_file.is_file():
		#si existe entonces abrimos el archivo CSV 
		with open('ventas.csv') as csvfile:
			reader = csv.DictReader(csvfile)

			if not 'CODIGO' in reader.fieldnames or not 'PRODUCTO' in reader.fieldnames or not 'CLIENTE' in reader.fieldnames or not 'CANTIDAD' in reader.fieldnames or not 'PRECIO' in reader.fieldnames:
				resultado[0] = False
				resultado[1] = 'Hay un nombre de campo en la cabecera del archivo CSV que no es válido, verifique que el archivo CSV contenga los campos "CODIGO, PRODUCTO, CLIENTE, CANTIDAD y PRECIO"'
				resultado[2] = 0
				return resultado

			#Pasamos el contenido a un tipo LISTA para manipularlo
			salida = list(reader)
			#Verificamos la integridad del archivo según los puntos requeridos.
			#Que ningún registro tenga una cantidad inválida de campos.
			i = 1
			largo = '0'
			codigo = ''
			valor1 = ''
			valor2 = ''
			valor3 = ''
			valor4 = ''
			#Agregamos una validación para controlar que el nombre de las cabeceras del archivo sean correctas			
			for row in salida:
				largo = len(row)
				codigo = row['CODIGO']
				largocodigo = len(codigo)
				tipoprecio = row['PRECIO']
				#Verifico que el largo del registro sea de 5 posiciones, ni mas ni menos
				if largo != 5:
					resultado[0] = False
					resultado[1] = 'Hay un registro con una cantidad inválida de campos, verifique el archivo de datos.'
					resultado[2] = i
					return resultado
					
				#Verifico que el código no sea vacío
				elif codigo == '':
					resultado[0] = False
					resultado[1] = 'Hay un código vacío.'
					resultado[2] = i
					return resultado

				#verifico que el largo del código sea de 6 caracteres
				elif largocodigo != 6:
					resultado[0] = False
					resultado[1] = 'El código no es del largo correcto.'
					resultado[2] = i
					return resultado

				#Verifico que el código sea formado por 3 letras y tres números
				elif formatoCodigo(codigo):
					resultado[0] = False
					resultado[1] = 'El código no tiene el formato correcto.'
					resultado[2] = i
					return resultado

				#Verificamos que la cantidad sea positiva y un nro entero
				elif not representaInt(row['CANTIDAD']):
					resultado[0] = False
					resultado[1] = 'La cantidad no es un valor válido.'
					resultado[2] = i
					return resultado

				#Verifico si el precio es un decimal
				elif not esDecimal(row['PRECIO']):
					resultado[0] = False
					resultado[1] = 'El precio no es válido.'
					resultado[2] = i
					return resultado

				i = i + 1

			resultado[0] = True
			resultado[1] = ''
			resultado[2] = 0
			return resultado
	else:
		resultado[0] = False
		resultado[1] = 'Error en el archivo de datos.'
		resultado[2] = 0
		return resultado


#Función para leer el archivo CSV (Sólo ejecutar si ya está validado antes)
def leerCSV(parametro):
	salida = []
	with open('ventas.csv') as csvfile:
		#cargamos el contenido de CSV a una variable tipo CSV DictReader
		reader = csv.DictReader(csvfile)
		#Pasamos el contenido a un tipo LISTA para manipularlo fácilmente
		listaVentas = list(reader)
		#Contamos la cantidad de registros existentes
		cantRegistros = len(listaVentas)
		#Si recibimos un parámetro entonces ejecutamos la accion según sea
		if parametro == 'ultimasVentas':
			#Realizamos el filtrado para enviar sólo los últimos 10 registros del CSV				
			for x in range(cantRegistros):
				#print(x)
				if (cantRegistros) - x <= 10:	
					#print(x)	
					#Voy agregando a la lista nueva los registros que me interesan (los ultimos 10)				
					salida.append(listaVentas[x])

		elif parametro == 'mejoresclientes':
			#realizamos el filtrado para enviar sólo los mejores 3 clientes del CSV
			#Creo un diccionario
			clientes = {}		
			#Recorro los registos
			for x in range(cantRegistros):
				#print(listaVentas[x]['CLIENTE'])
				#Voy cargando los distintos clientes a una lista y sumándoles los montos de las ventas
				if not listaVentas[x]['CLIENTE'] in clientes:
					clientes[listaVentas[x]['CLIENTE']] = float(listaVentas[x]['PRECIO']) * float(listaVentas[x]['CANTIDAD'])
				else:
					clientes[listaVentas[x]['CLIENTE']] = float(clientes[listaVentas[x]['CLIENTE']]) + ( float(listaVentas[x]['PRECIO']) * float(listaVentas[x]['CANTIDAD']) )
			
			#Defino un diccionario vacío para llenarlo con valores ordenados
			clientesOrdenados = {}	
			#Ordeno las claves del diccionario por el mayor valor
			clientes_sorted_keys = sorted(clientes, key=clientes.get, reverse=True)
			i=0
			for r in clientes_sorted_keys:
			    clientesOrdenados[r] = clientes[r]
			    i = i + 1
			    if i==3:
			    	break

			salida = clientesOrdenados
		
		elif parametro == 'productosmasvendidos':
			#Defino un diccionario vacío
			productos = {}	
			#Genero una lista con una KEY compuesta por codigo,producto y le asigno el valor
			for x in range(cantRegistros):
				KEY = listaVentas[x]['CODIGO'] + ',' + listaVentas[x]['PRODUCTO']

				if not KEY in productos:
					productos[KEY] = int(listaVentas[x]['CANTIDAD'])
				else:
					productos[KEY] = int(productos[KEY]) + int(listaVentas[x]['CANTIDAD'])

			productosOrdenados = {}	
			#Ordeno las claves del diccionario por el mayor valor
			productos_sorted_keys = sorted(productos, key=productos.get, reverse=True)
			i=0
			for r in productos_sorted_keys:
			    productosOrdenados[r] = productos[r]
			    i = i + 1
			    if i==3:
			    	break

			salida = productosOrdenados

		else:
			#Aquí manandamos todos los registros del archivo 
			salida = listaVentas

		return salida


#Función par comprobar si la cantidad representa un número entero
def representaInt(s):
    try: 
        int(s)
        #Si es un nro negativo ya invalidamos
        if "-" in s:
        	return False
        return True
    except ValueError:
        return False


#Función para verificar el formáto del código
def formatoCodigo(s):
	if not s[0].isalpha():
		return True
	if not s[1].isalpha():
		return True
	if not s[2].isalpha():
		return True
	if not representaInt(s[3]):
		return True
	if not representaInt(s[4]):
		return True
	if not representaInt(s[5]):
		return True
	return False


#Función para verificar si un número es un decimal
def esDecimal(s):
    try:
        float(s)
        return True
    except:
        return False



#Función para obtener una lista de produtos por cliente
def getProductosxCliente(cliente):
	#leo el CSV y genero el filtrado correspondiente
	#print(cliente)
	salida = []
	listaVentas = leerCSV(cliente)
	cantRegistros = len(listaVentas)
	if cliente != 'todos':
		for x in range(cantRegistros):
			#print(x)
			if cliente.lower() in listaVentas[x]['CLIENTE'].lower():
				#Voy agregando a la lista nueva los registros que coinciden		
				salida.append(listaVentas[x])
	else:
		salida = listaVentas

	return salida


#Función para obtener una lista de clientes por un prodcuto
def getClientesxProducto(producto):
	#leo el CSV y genero el filtrado correspondiente
	#print(producto)
	salida = []
	listaVentas = leerCSV(producto)
	cantRegistros = len(listaVentas)
	if producto != 'todos':
		for x in range(cantRegistros):
			#print(x)
			if producto.lower() in listaVentas[x]['PRODUCTO'].lower():
				#Voy agregando a la lista nueva los registros que coinciden		
				salida.append(listaVentas[x])
	else:
		salida = listaVentas

	return salida




###################################
# MÉTODOS PARA USUARIOS LOGUEADOS #
###################################

@app.route('/')
def index():
	resultado = validarCSV()
	if(resultado[0]):
		#Si el usuario está logueado muestro las ultimas ventas en la página home
		if 'username' in session:
			#Cargar las ultimas ventas
			ultimasventas = leerCSV('ultimasVentas')
			return render_template('home.html', username=session['username'], ventas=ultimasventas)
		#Si el usuario no está logueado voy a la pantalla de inicio del programa
		else:
			return render_template('index.html', fecha_actual=datetime.utcnow())
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])


@app.route('/productosporcliente/<cliente>', methods=['GET', 'POST'])
def productosporcliente(cliente):
	resultado = validarCSV()
	if(resultado[0]):

	    formulario = BuscarProductosxClienteForm()
	    if formulario.validate_on_submit():
	        print(formulario.cliente.name)
	        return redirect(url_for('productosporcliente', cliente=formulario.cliente.data))
	    #Si recibimos un cliente generamos la tabla con productos
	    if(len(cliente)>=3):
	    	lista=getProductosxCliente(cliente)
	    	if len(lista)==0 and cliente!='Todos':
	    		flash('No hubo resultado para: '+cliente )
	    else:
	    	lista = []
	    	flash('Debe ingresar al menos 3 letras del nombre ó apellido para que la búsqueda se ejecute')
	    
	    return render_template('productosporcliente.html', form=formulario, cliente=cliente, listaProductos=lista)
	else:
			#rendereo el error
			return render_template('error.html',mensaje=resultado[1],valor=resultado[2])


@app.route('/clientesporproducto/<producto>', methods=['GET', 'POST'])
def clientesporproducto(producto):
	resultado = validarCSV()
	if(resultado[0]):
	    formulario = BuscarClientesxProductoForm()
	    if formulario.validate_on_submit():
	        print(formulario.producto.name)
	        return redirect(url_for('clientesporproducto', producto=formulario.producto.data))
	    #Si recibimos un producto generamos la tabla con clientes
	    if(len(producto)>=3):
	    	lista=getClientesxProducto(producto)
	    	if len(lista)==0 and producto!='Todos':
	    		flash('No hubo resultado para: '+producto )
	    else:
	    	lista = []
	    	flash('Debe ingresar al menos 3 caracteres del producto para que la búsqueda se ejecute')

	    return render_template('clientesporproducto.html', form=formulario, producto=producto, listaClientes=lista)
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])



@app.route('/productosmasvendidos')
def productosmasvendidos():
	resultado = validarCSV()
	if(resultado[0]):
		#Si el usuario está logueado muestro la lista con productos mas vendidos
		if 'username' in session:
			productosmasvendidos = leerCSV('productosmasvendidos')
			return render_template('productosmasvendidos.html', lista=productosmasvendidos)
		#Si el usuario no está logueado voy a la pantalla de inicio del programa
		else:
			return render_template('index.html', fecha_actual=datetime.utcnow())	
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])



@app.route('/mejoresclientes')
def mejoresclientes():
	resultado = validarCSV()
	if(resultado[0]):
		if(validarCSV):
			#Si el usuario está logueado muestro la lista con mejores clientes
			if 'username' in session:
				mejoresclientes = leerCSV('mejoresclientes')
				return render_template('mejoresclientes.html', lista=mejoresclientes)
			#Si el usuario no está logueado voy a la pantalla de inicio del programa
			else:
				return render_template('index.html', fecha_actual=datetime.utcnow())
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])





######################################
# MÉTODOS PARA usuarios NO LOGUEADOS #
######################################

@app.route('/ingresar', methods=['GET', 'POST'])
def ingresar():
	resultado = validarCSV()
	if(resultado[0]):
	    formulario = LoginForm()
	    if formulario.validate_on_submit():
	        with open('usuarios') as archivo:
	            archivo_csv = csv.reader(archivo)
	            registro = next(archivo_csv)
	            while registro:
	                if formulario.usuario.data == registro[0] and formulario.password.data == registro[1]:
	                    #flash('Bienvenido')
	                    session['username'] = formulario.usuario.data
	                    #Cargo las ultimas ventas
	                    listaUltimasVentas = leerCSV('ultimasVentas')
	                    return render_template('home.html',username=session['username'],ventas=listaUltimasVentas)
	                registro = next(archivo_csv, None)
	            else:
	                flash('Revisá tu nombre de usuario y contraseña')
	                return redirect(url_for('ingresar'))
	    return render_template('login.html', formulario=formulario)
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])

@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
	resultado = validarCSV()
	if(resultado[0]):
	    formulario = RegistrarForm()
	    if formulario.validate_on_submit():
	        if formulario.password.data == formulario.password_check.data:
	            with open('usuarios', 'a+') as archivo:
	                archivo_csv = csv.writer(archivo)
	                registro = [formulario.usuario.data, formulario.password.data]
	                archivo_csv.writerow(registro)
	            flash('Usuario creado correctamente')
	            return redirect(url_for('ingresar'))
	        else:
	            flash('Las contraseñas no coinciden')
	    return render_template('registrar.html', form=formulario)
	else:
		#rendereo el error
		return render_template('error.html',mensaje=resultado[1],valor=resultado[2])



@app.route('/logout', methods=['GET'])
def logout():
    if 'username' in session:
        session.pop('username')
        return render_template('logged_out.html')
    else:
        return redirect(url_for('index'))



#####################
# MANEJO DE ERRORES #
#####################

@app.errorhandler(404)
def no_encontrado(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def error_interno(e):
    return render_template('500.html'), 500




if __name__ == "__main__":
    # app.run(host='0.0.0.0', debug=True)
    manager.run()
