###################
## Honeybee INC.  #
###################

ALUMNOS: Diego Giménez y Emanuel Odstrcil, 02/11/2018 - Examen Parcial, Paradigmas de Programación


-----------------------------
DESCRIPCIÓN GENERAL DE DISEÑO
-----------------------------

El programa está basado en el template "supreme-happiness", el cual fué customizado para 
cumplir con las necesidades del requerimiento.

Si observamos el código fuente del archivo app.py, vamos a encontrarnos con 3 grandes bloques de código
bien definidos. 
Decidimos estructurarlo así para tener una visión clara y segmentada del código.
Así como también para poder trabajar en paralelo en las diferentes partes del programa.

Tratamos de respetar la coherencia de los nombres de las funciónes y las páginas HTML vinculadas en la 
carpeta "templates" para poder identificar las relaciones fácilmente.

Decidimos leer el contenido del CSV en cada consulta realizada por el cleinte para mantener los datos 
"frescos" a los ojos del usuario.

A continuación detallaremos los 3 bloques principales de código contenidos en el archivo app.py


************************************
* BLOQUE1 - FUNCIONES DE USO COMÚN * 
************************************

En este bloque vamos a encontrar las funciones comunes a todo el sistema, estas se usan desde
varios lugares, hicimos esto esto para poder reutilizar código y simplificar su entendimiento.

A continuación describiremos el funcionamiento de cada una de ellas.

+ Función validarCSV: 
Esta función se encarga de responder a la validación solicitada en el punto 1.2.1, se hace 
uso de la funcion "DicReader" de la clase CSV. Luego se abre el archivo CSV y se carga su 
contenido en la variable reader. Posteriormente la convertimos a tipo lista para poder tratarla 
fácilmente.
A través de un bucle FOR, recorremos todas las filas del archivo (ya cargado en memoria) y vamos 
realizando las pruebas de validación solicitadas. En caso de que algún paso de validación falle,
la funcion retorna una lista de 3 posiciones con:
Valor false en la posicion 0, mensaje del error en la posicion 1 y número de línea del CSV que contiene el error en la posicion 2.
EJEMPLO:
array [false,'mensaje',4]


+ Función leerCSV: 
Esta función lee el contenido del CSV (Se supone previeamente válidado) y puede recibir un parámetro,
el cual determina qué tabla de salida devolverá.
Con el parámetro "ultimasVentas" devuelve una lista con las últimas 10 ventas.
Con el parámetro "mejoresclientes" devuelve una lista con los 3 mejores clientes
Con el parámetro "productosmasvendidos" devuelve una lista con los 3 productos más vendidos. 
En caso de pasar otro valor, devolverá la totalidad de los registros del archivo CSV.

+ Función representaInt:
La utilizamos para verificar si el parámetro que se le pasa (texto) representa un número entero no negativo.
Devuelve True si está bien o False si es negativo o no es un número

+ Función formatoCodigo:
La utilizamos para verificar que el código de un producto (el cual se le pasa a esta función como parámetro)
contiene el formato 3 letas + 3 números

+ Función esDecimal:
Como su nombre lo indica, verifica si el parámetro que le pasamos (texto) es una representacion del tipo decimal
Si es así devuelve True

+ Función getProductosxCliente:
Esta función recibe como parámetro (texto) el nombre, apellido de un cliente ó parte de estos (mínimo 3 caracteres). 
Para luego realizar el recorrido de la lista completa de registros del archivo CSV y va acumulando en otra lista 
los productos que fueron comprados por dicho cliente.

+ Función getClientesxProducto:
Esta función recibe como parámetro (texto) el nombre de un producto ó parte de este (mínimo 3 caracteres). 
Para luego realizar el recorrido de la lista completa de registros del archivo CSV e ir acumulando en otra lista 
los clientes que fueron compradores de dicho prodcuto.



*********************************************************************
* BLOQUE2 - FUNCIÓNES PARA RENDEREO DE HTML - USUARIOS AUTENTICADOS * 
*********************************************************************

En este bloque vamos a encontras las funciónes utilizadas para realizar el procesamiento de parámetros del cliente 
web y rendereno de las páginas HTML, así como su contenido dinámico. Enfocadas a usuario autenticados.

A continuación describiremos el funcionamiento de cada una de ellas.

+ Función index: 
Si bien esta función responde tanto a usuario autenticados como a no autenticados decidimos colocarla en este bloque 
ya que es la primera del en ejecutarse al correr la aplicación WEB.
Esta función realiza la verificación de la sesión de usuario y: Si está logueado lo manda a la página Home.html,
en la cual se le mostrará el listado de las últias 10 ventas realizadas. Y si no está logueado lo manda a index.html.
En la cual se le muesta el logo de la aplicación y los creditos.

+ Función productosporcliente: 
Esta se encarga de renderear el formulario de ingreso de datos para generar el listado de productos comprados por 
un determinado cliente. Una vez enviado el parámetro se genera la tabla correspondiente y se muestra al cliente.


+ Función clientesporProducto: 
Esta se encarga de renderear el formulario de ingreso de datos para generar el listado de clientes que compraron 
un determinado producto. Una vez enviado el parámetro se genera la tabla correspondiente y se muestra al cliente.


+ Función productosmasvendidos:
Esta se encarga de renderear la tabla con el listado de productos mas vendidos.


+ Función mejoresclientes:
Esta se encarga de renderear la tabla con el listado de mejores clientes.



************************************************************************
* BLOQUE3 - FUNCIÓNES PARA RENDEREO DE HTML - USUARIOS NO AUTENTICADOS * 
************************************************************************

En este bloque vamos a encontras las funciónes utilizadas para realizar el procesamiento de parámetros del cliente 
web y rendereno de las páginas HTML, así como su contenido dinámico.

A continuación describiremos el funcionamiento de cada una de ellas.

+ Función ingresar: 
Esta función puede soportar parametros tanto por GET o por POST.
Se encarga de realizar el rendereo del formulario de ingreso para el usuario, así como también la generacion de 
la tabla de salida para mostrar en el HTML de las últimas ventas, luego de que el usuario se autentique correctamente.

+ Funcion registrar:
Esta función puede soportar parametros tanto por GET o por POST.
Realiza el alta de un usuario nuevo recibiendo los parámetros del formulario de registro el cual es rendereado por esta misma función.

+ Funcion logout:
Esta función elimina la sesión activa del usuario y redirige a la página de salida "logged_out.html"

+ Función no_encontrados:
Se encarga de mostrar una pantalla amigable cuando la aplicación no encuentra un recurso solicitado, "Error 404".

+ Función error_interno:
Se encarga de  mostrar una pantalla amigable cuando la aplicación genera un error interno, "Error 500".